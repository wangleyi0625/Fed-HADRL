import os
import time
import warnings
import itertools
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import seaborn as sns
from collections import deque

PALETTE_VITAL = ['#a30543', '#f36f43', '#fbda83', '#e9f4a3', '#80cba4', '#4965b0']
PALETTE_DUSK  = ['#274753', '#297270', '#299d8f', '#8ab07c', '#e7c66b', '#f3a361', '#e66d50']

sns.set_style("whitegrid", {'axes.facecolor': '#ffffff', 'figure.facecolor': '#ffffff'})
sns.set_context("paper", font_scale=1.3, rc={"lines.linewidth": 2.5})
plt.rcParams.update({
    'font.family': 'Times New Roman',
    'font.serif': ['Times New Roman', 'DejaVu Serif'],
    'mathtext.fontset': 'stix',
    'axes.unicode_minus': False,
    'figure.dpi': 200,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.facecolor': '#ffffff',
    'figure.facecolor': '#ffffff',
    'axes.facecolor': '#ffffff',
    'legend.frameon': True,
    'legend.fancybox': True,
    'legend.shadow': False,
    'axes.titlesize': 18,
    'axes.labelsize': 15,
    'xtick.labelsize': 13,
    'ytick.labelsize': 13,
})

warnings.filterwarnings("ignore")
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
try:
    import tensorflow as tf
    from tensorflow.keras import Sequential, Model
    from tensorflow.keras.layers import Dense, Input, Concatenate, Lambda
    tf.get_logger().setLevel("ERROR")
    tf.autograph.set_verbosity(0)
except ImportError:
    tf = None
    print("TensorFlow is required. Please install it.")

def _hypot(*a):
    return float(np.sqrt(sum(np.asarray(x, dtype=float) ** 2 for x in a)))

# 2D segment intersection test used for LOS blocking
def _seg_intersect(x1, y1, x2, y2, x3, y3, x4, y4):
    d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(d) < 1e-10:
        return False
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / d
    u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / d
    return 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0

# a building only blocks the link when it is taller than the transmitter
def _los_blocked(x1, y1, x2, y2, buildings, h_tx=None):
    for b in buildings:
        if h_tx is not None and h_tx > getattr(b, 'height', 0.0):
            continue
        rx, ry, rw, rh = b.x, b.y, b.w, b.h
        if rx <= x1 <= rx + rw and ry <= y1 <= ry + rh:
            return True
        if rx <= x2 <= rx + rw and ry <= y2 <= ry + rh:
            return True
        edges = [(rx, ry, rx+rw, ry), (rx+rw, ry, rx+rw, ry+rh),
                 (rx+rw, ry+rh, rx, ry+rh), (rx, ry+rh, rx, ry)]
        for ex1, ey1, ex2, ey2 in edges:
            if _seg_intersect(x1, y1, x2, y2, ex1, ey1, ex2, ey2):
                return True
    return False

# 3GPP-style path loss at 28 GHz (LOS / NLOS plus building penetration)
def _path_loss_db(cfg, d_2d, h_tx, h_rx=1.5, los=True):
    d_3d = np.sqrt(d_2d**2 + (h_tx - h_rx)**2)
    d_3d = max(d_3d, 1.0)
    pl = 32.4 + 20.0 * np.log10(cfg.freq_GHz) + 20.0 * np.log10(d_3d)
    if not los:
        pl += cfg.building_loss_db
    return float(pl)

# log-normal shadow fading
def _shadow_fade_db(cfg, los=True):
    sigma = cfg.shadow_los_std if los else cfg.shadow_nlos_std
    return float(np.random.normal(0.0, sigma))

# thermal noise power integrated over the configured bandwidth
def _thermal_noise_dbm(cfg):
    bw_hz = cfg.bw_MHz * 1e6
    return -174.0 + 10.0 * np.log10(bw_hz) + cfg.noise_figure_db

# SINR (dB) from signal and interference powers, both in dBm
def _sinr_db(cfg, sig_rx_dbm, int_rx_dbm_list):
    sig_lin = 10.0 ** (sig_rx_dbm / 10.0)
    int_lin = sum(10.0 ** (p / 10.0) for p in int_rx_dbm_list)
    n0_lin = 10.0 ** (_thermal_noise_dbm(cfg) / 10.0)
    sinr_lin = sig_lin / (int_lin + n0_lin + 1e-15)
    return float(10.0 * np.log10(max(sinr_lin, 1e-15)))

# BS link: strongest serving cell, co-band interference only
def _bs_sinr(cfg, user, bs_list, buildings, want_bs_idx=-1):
    rx_list = []
    for i, b in enumerate(bs_list):
        d2d = _hypot(b.x - user.x, b.y - user.y)
        los = not _los_blocked(b.x, b.y, user.x, user.y, buildings, h_tx=25.0)
        pl = _path_loss_db(cfg, d2d, h_tx=25.0, h_rx=1.5, los=los)
        sf = _shadow_fade_db(cfg, los=los)
        rx = cfg.bs_tx_power_dbm - pl - sf
        band = getattr(b, 'band', i % cfg.n_bands)
        rx_list.append((rx, i, band, los))
    if want_bs_idx >= 0:
        rx_list.sort(key=lambda x: 0 if x[1] == want_bs_idx else 1)
    else:
        rx_list.sort(key=lambda x: -x[0])
    sig_rx, sig_idx, sig_band, _ = rx_list[0]
    int_list = [r[0] for r in rx_list[1:] if r[2] == sig_band]
    return _sinr_db(cfg, sig_rx, int_list), sig_idx, sig_band

# best UAV-to-user link (angle-based LOS, no building test)
def _uav_sinr(cfg, user, uav_list, want_uav_idx=-1):
    rx_list = []
    for i, v in enumerate(uav_list):
        d2d = _hypot(v.x - user.x, v.y - user.y)
        theta = np.degrees(np.arctan2(v.z, max(d2d, 0.1)))
        los = (theta > cfg.uav_los_angle) and (d2d > 1.0)
        pl = _path_loss_db(cfg, d2d, h_tx=v.z, h_rx=1.5, los=los)
        sf = _shadow_fade_db(cfg, los=los)
        rx = cfg.uav_tx_power_dbm - pl - sf
        band = getattr(v, 'band', i % cfg.n_bands)
        rx_list.append((rx, i, band, los))
    if want_uav_idx >= 0:
        rx_list.sort(key=lambda x: 0 if x[1] == want_uav_idx else 1)
    else:
        rx_list.sort(key=lambda x: -x[0])
    sig_rx, sig_idx, sig_band, _ = rx_list[0]
    int_list = [r[0] for r in rx_list[1:] if r[2] == sig_band]
    return _sinr_db(cfg, sig_rx, int_list), sig_idx, sig_band

class Config:
    # simulation timing and scenario geometry
    T_sim = 100
    dt = 0.2
    N_users =30
    N_uavs = 10
    N_ground_bs = 5
    N_buildings = 20
    map_size = (600, 600)
    terrain_seed = 42
    warmup_t = 2.0

    # radio, path loss and priority SINR thresholds
    freq_GHz = 28.0
    bs_tx_power_dbm = 22
    uav_tx_power_dbm = 20
    bw_MHz = 100.0
    noise_figure_db = 10.0
    sinr_threshold_db = 2.0
    uav_los_angle = 3.5
    Kp_priority = 4
    priority_sinr_thresholds = {
        'commercial':  5.0,
        'office':      3.0,
        'residential': 1.5,
        'other':       1.0,
    }
    priority_region_radius = 35.0
    shadow_los_std = 4.0
    shadow_nlos_std = 6.5
    building_loss_db = 29.0
    n_bands = 4

    # UAV flight envelope
    uav_speed_max = 20.0
    uav_accel_max = 6.0
    uav_opt_h = 70.0
    uav_min_h = 40.0
    uav_max_h = 120.0

    # user mobility (random-walk model)
    user_speed_mean = 0.15
    user_speed_std = 0.08
    user_alpha = 0.9

    # low-level DDPG
    state_dim = 12
    action_dim = 2
    gamma = 0.95
    lr = 0.003
    eps = 0.15
    eps_min = 0.02
    eps_decay = 0.99
    tau = 0.005
    ou_sigma = 0.2
    ou_theta = 0.15

    # high-level Q-learning (sub-goal selection)
    high_state_dim = 9
    high_action_dim = 9
    high_decision_interval = 10
    high_gamma = 0.9
    high_lr = 0.005
    high_eps = 0.3
    high_eps_min = 0.05
    high_eps_decay = 0.98
    high_batch = 32
    high_mem_size = 5000
    high_target_update = 200
    w_high_cover = 5.0
    w_high_energy = 0.5

    # federated aggregation (attention-driven adaptive interval) and HER
    fed_round_interval = 10
    min_agg_freq = 5
    max_agg_freq = 20
    fed_attention_dim = 5

    her_k = 4
    her_ratio = 0.3

    # reward weights
    w_cover = 20.0
    w_global = 50.0
    w_energy = 1.0
    w_shape = 0.0
    w_time_penalty = 0.1
    w_dist_far = 2.0
    dist_far_threshold = 300.0

    # energy model and collision avoidance
    k_energy = 0.05
    k_hover = 0.012

    avoid_building_dist = 25.0
    avoid_bs_dist = 30.0
    avoid_force_gain = 60.0

    # replay buffers and coarse grid
    grid_size = 3

    mem_size = 20000
    batch = 64
    target_update = 100
    max_users_per_uav = 6

class FedManager:
    def __init__(self, cfg, state_dim, action_dim):
        self.cfg = cfg
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.global_model = None
        self.global_weights = None
        self.step_counter = 0
        self.current_agg_interval = cfg.fed_round_interval
        self.model_diff_history = deque(maxlen=10)
        self.tf_ok = tf is not None

        if self.tf_ok:
            self.global_model = self._build_model()
            self.global_weights = {
                'actor': self.global_model.get_weights(),
                'critic': None
            }
            self.attention_net = Sequential([
                Dense(32, activation='relu', input_dim=cfg.fed_attention_dim),
                Dense(16, activation='relu'),
                Dense(1, activation='linear')
            ])
            self.attention_net.compile(optimizer='adam', loss='mse')
            self.attention_memory = deque(maxlen=2000)
            self._agg_counter = 0

    # global actor used as the reference model for federated averaging
    def _build_model(self):
        if not self.tf_ok:
            return None
        model = Sequential([
            Dense(64, input_dim=self.state_dim, activation='relu'),
            Dense(32, activation='relu'),
            Dense(self.action_dim, activation='tanh')
        ])
        model.compile(optimizer='adam', loss='mse')
        return model

    # per-UAV context (coverage, energy, model divergence) fed to the attention net
    def get_context_vector(self, uav):
        blind = [u for u in uav.sim.users if not u.bs_cover]
        cov_cnt = sum(1 for u in blind if getattr(u, '_uav_id', -1) == uav.id)
        cov_contrib = cov_cnt / max(len(blind), 1)
        load = len(uav.users) / max(self.cfg.max_users_per_uav, 1)
        energy_eff = cov_cnt / (cov_cnt + 0.5 * uav.energy + 1e-6)
        speed = _hypot(uav.vx, uav.vy, uav.vz)
        speed_norm = min(speed / self.cfg.uav_speed_max, 1.0)
        diff = 0.0
        if self.tf_ok and getattr(uav, 'agent', None) is not None and uav.agent.local_model is not None:
            local_w = uav.agent.get_weights()
            if local_w is not None and self.global_weights is not None:
                total = 0.0
                n_params = 0
                for lw, gw in zip(local_w['actor'], self.global_weights['actor']):
                    if np.asarray(lw).shape != np.asarray(gw).shape:
                        continue
                    total += float(np.sum((lw - gw) ** 2))
                    n_params += lw.size
                for lw, gw in zip(local_w['critic'], self.global_weights.get('critic') or []):
                    if np.asarray(lw).shape != np.asarray(gw).shape:
                        continue
                    total += float(np.sum((lw - gw) ** 2))
                    n_params += lw.size
                diff = float(np.sqrt(total / max(n_params, 1)))
                diff = min(diff, 1.0)
        return np.array([cov_contrib, load, energy_eff, speed_norm, diff], dtype=np.float32)

    # attention-weighted FedAvg: weight of each UAV comes from its context vector
    def aggregate(self, local_weights_list, context_vectors):
        if not self.tf_ok or not local_weights_list:
            return None
        scores = []
        for ctx in context_vectors:
            s = self.attention_net.predict(ctx[np.newaxis], verbose=0)[0, 0]
            scores.append(float(s))
        scores = np.array(scores)
        scores = scores - np.max(scores)
        exp_scores = np.exp(scores)
        attn_weights = exp_scores / (np.sum(exp_scores) + 1e-8)

        extract_indices = [0, 1, 2, 3]
        new_actor = [np.array(w, copy=True) for w in local_weights_list[0]['actor']]
        shapes_ok = True
        for idx in extract_indices:
            shape_set = set()
            for w in local_weights_list:
                if idx >= len(w['actor']):
                    shapes_ok = False; break
                shape_set.add(tuple(np.asarray(w['actor'][idx]).shape))
            if len(shape_set) > 1:
                shapes_ok = False; break
        if shapes_ok:
            for idx in extract_indices:
                layer_sum = np.zeros_like(np.asarray(local_weights_list[0]['actor'][idx]))
                for i, w in enumerate(local_weights_list):
                    layer_sum += attn_weights[i] * np.asarray(w['actor'][idx])
                new_actor[idx] = layer_sum
        critic_extract_indices = [0, 1]
        new_critic = [np.array(w, copy=True) for w in local_weights_list[0]['critic']]
        critic_shapes_ok = True
        for idx in critic_extract_indices:
            shape_set = set()
            for w in local_weights_list:
                if idx >= len(w['critic']):
                    critic_shapes_ok = False
                    break
                shape_set.add(tuple(np.asarray(w['critic'][idx]).shape))
            if len(shape_set) > 1:
                critic_shapes_ok = False
                break
        if critic_shapes_ok:
            for idx in critic_extract_indices:
                layer_sum = np.zeros_like(np.asarray(local_weights_list[0]['critic'][idx]))
                for i, w in enumerate(local_weights_list):
                    layer_sum += attn_weights[i] * np.asarray(w['critic'][idx])
                new_critic[idx] = layer_sum
        self.global_weights = {
            'actor': new_actor,
            'critic': new_critic
        }

        ctx_array = np.array(context_vectors, dtype=np.float32)
        perf_scores = np.array([
            float(ctx[0] * 2.0 - ctx[1] * 0.5 + ctx[2] * 1.5 - ctx[4] * 0.3)
            for ctx in context_vectors
        ], dtype=np.float32)
        for i in range(len(ctx_array)):
            self.attention_memory.append((ctx_array[i], perf_scores[i]))
        try:
            self.attention_net.fit(ctx_array, perf_scores, epochs=1, verbose=0)
        except Exception:
            pass
        self._agg_counter += 1
        if self._agg_counter % 3 == 0 and len(self.attention_memory) >= 32:
            try:
                mb = [self.attention_memory[i] for i in
                      np.random.choice(len(self.attention_memory), 32, replace=False)]
                X = np.array([x[0] for x in mb], dtype=np.float32)
                Y = np.array([x[1] for x in mb], dtype=np.float32)
                self.attention_net.fit(X, Y, epochs=2, verbose=0)
            except Exception:
                pass
        return attn_weights

    # L2 divergence between local and global weights
    def compute_model_diff(self, local_weights_list):
        if self.global_weights is None or self.global_weights.get('critic') is None or not local_weights_list:
            return 0.0
        total_diff = 0.0
        count = 0
        for lw in local_weights_list:
            diff = 0.0
            n_params = 0
            for layer_lw, layer_gw in zip(lw['actor'], self.global_weights['actor']):
                diff += np.sum((layer_lw - layer_gw) ** 2)
                n_params += layer_lw.size
            for layer_lw, layer_gw in zip(lw['critic'], self.global_weights['critic']):
                diff += np.sum((layer_lw - layer_gw) ** 2)
                n_params += layer_lw.size
            diff = np.sqrt(diff / max(n_params, 1))
            total_diff += diff
            count += 1
        avg_diff = total_diff / max(count, 1)
        self.model_diff_history.append(avg_diff)
        if avg_diff > 0.3:
            self.current_agg_interval = max(self.cfg.min_agg_freq, self.current_agg_interval - 2)
        elif avg_diff < 0.05:
            self.current_agg_interval = min(self.cfg.max_agg_freq, self.current_agg_interval + 2)
        return avg_diff

    # adaptive synchronization: interval shrinks/grows with predicted divergence
    def should_aggregate(self):
        self.step_counter += 1
        return self.step_counter % self.current_agg_interval == 0

    def get_global_weights(self):
        return self.global_weights

class HERBuffer:
    def __init__(self, capacity, her_ratio, map_size=(1000, 1000)):
        self.buffer = deque(maxlen=capacity)
        self.her_ratio = her_ratio
        self.map_w, self.map_h = float(map_size[0]), float(map_size[1])

    def add(self, s, a, r, s2, done, goal, end_pos=None):
        entry = (s, a, r, s2, done, goal, end_pos)
        self.buffer.append(entry)

    # mixed batch: replay samples plus HER-relabelled transitions
    def sample(self, batch_size):
        if len(self.buffer) < batch_size:
            return None
        idx = np.random.choice(len(self.buffer), batch_size, replace=False)
        batch = [list(self.buffer[i]) for i in idx]
        cand_flags = np.zeros(len(batch), dtype=np.float32)
        for j, entry in enumerate(batch):
            s, a, r, s2, done, goal, end_pos = entry[:7]
            if not done and goal is not None:
                cand_flags[j] += 0.4
                if end_pos is not None:
                    density = float(np.clip(1.0 - s2[8], 0, 1))
                    cand_flags[j] += density
        her_count = int(batch_size * self.her_ratio)
        cand_sum = cand_flags.sum()
        if cand_sum < 1e-6:
            cand_flags = np.ones(len(batch), dtype=np.float32) / len(batch)
        else:
            cand_flags = cand_flags / cand_sum
        j_seq = np.random.choice(len(batch), size=her_count, replace=True, p=cand_flags)
        for j in j_seq:
            s, a, r, s2, done, goal, _end_pos = batch[j][:7]
            if goal is None:
                continue
            k = int(np.random.randint(len(self.buffer)))
            if k == int(idx[j]):
                continue
            fut_end = self.buffer[k][6]
            if fut_end is None:
                continue
            new_goal = (float(fut_end[0]), float(fut_end[1]))
            cur_x, cur_y = float(s[0] * self.map_w), float(s[1] * self.map_h)
            d_new = _hypot(cur_x - new_goal[0], cur_y - new_goal[1])
            done_her = d_new < 80.0
            r_her = 10.0 if done_her else -d_new / 100.0
            s_her = np.array(s, copy=True)
            s_her[2] = new_goal[0] / self.map_w
            s_her[3] = new_goal[1] / self.map_h
            s2_her = np.array(s2, copy=True)
            s2_her[2] = new_goal[0] / self.map_w
            s2_her[3] = new_goal[1] / self.map_h
            s_her[6] = (new_goal[0] - cur_x) / self.map_w
            s_her[7] = (new_goal[1] - cur_y) / self.map_h
            s_her[8] = np.clip(d_new / 200.0, 0, 1)
            batch.append((s_her, a, r_her, s2_her, done_her, new_goal, None))
        return [x[:5] for x in batch]

class LocalDDPG:
    def __init__(self, cfg, idx, fed_manager, her_buffer):
        self.cfg = cfg
        self.idx = idx
        self.fed_manager = fed_manager
        self.her_buffer = her_buffer
        self.r_hist = []
        self.l_hist = []
        self.ema_r = 0.0
        self.tf_ok = tf is not None
        self.local_mem = deque(maxlen=cfg.mem_size)
        self.steps = 0
        self.last_goal = None
        self._ou_state = np.zeros(cfg.action_dim, dtype=np.float32)

        if self.tf_ok:
            self.local_model = self._build_actor()
            self.critic = self._build_critic()
            self.target_model = self._build_actor()
            self.target_critic = self._build_critic()
            self.target_model.set_weights(self.local_model.get_weights())
            self.target_critic.set_weights(self.critic.get_weights())

    # actor: state -> 2D displacement
    def _build_actor(self):
        model = Sequential([
            Dense(64, input_dim=self.cfg.state_dim, activation='relu'),
            Dense(32, activation='relu'),
            Dense(self.cfg.action_dim, activation='tanh')
        ])
        model.compile(optimizer=tf.keras.optimizers.Adam(self.cfg.lr), loss='mse')
        return model

    # critic: (state, action) -> Q value
    def _build_critic(self):
        state_input = Input(shape=(self.cfg.state_dim,))
        action_input = Input(shape=(self.cfg.action_dim,))
        x = Concatenate()([state_input, action_input])
        x = Dense(64, activation='relu')(x)
        x = Dense(32, activation='relu')(x)
        q = Dense(1)(x)
        model = Model([state_input, action_input], q)
        model.compile(optimizer=tf.keras.optimizers.Adam(self.cfg.lr), loss='mse')
        return model

    def set_weights(self, weights, alpha=0.7):
        if not self.tf_ok or weights is None:
            return
        local_a = self.local_model.get_weights()
        local_c = self.critic.get_weights()
        new_a = list(local_a)
        for i, (gw, lw) in enumerate(zip(weights['actor'], local_a)):
            if np.asarray(gw).shape == np.asarray(lw).shape:
                new_a[i] = alpha * np.asarray(gw) + (1 - alpha) * np.asarray(lw)
        new_c = list(local_c)
        for i, (gw, lw) in enumerate(zip(weights.get('critic') or [], local_c)):
            if np.asarray(gw).shape == np.asarray(lw).shape:
                new_c[i] = alpha * np.asarray(gw) + (1 - alpha) * np.asarray(lw)
        self.local_model.set_weights(new_a)
        self.critic.set_weights(new_c)

    def get_weights(self):
        if not self.tf_ok:
            return None
        return {
            'actor': self.local_model.get_weights(),
            'critic': self.critic.get_weights()
        }

    # normalised goal-relevant features shared by actor and critic
    def targets(self, uav, sim):
        if sim is None:
            return [(uav.x, uav.y)] * 3
        blind = [u for u in sim.users if not u.bs_cover]
        bad = [u for u in blind if not u._covered]
        t0 = (uav.x, uav.y)
        if bad:
            my_bad = [u for u in bad if getattr(u, '_uav_id', -1) == uav.id]
            pool = my_bad if my_bad else bad
            u = min(pool, key=lambda x: _hypot(x.x - uav.x, x.y - uav.y))
            t0 = (u.x, u.y)
        t1 = (uav.x, uav.y)
        if hasattr(sim, 'get_schedule_target'):
            target = sim.get_schedule_target(self.idx)
            if target is not None:
                t1 = target
        t2 = (uav.x, uav.y)
        if bad:
            my_bad2 = [u for u in bad if getattr(u, '_uav_id', -1) == uav.id]
            pool2 = my_bad2 if my_bad2 else bad
            u = max(pool2, key=lambda x: x.total_time - x.cover_time + np.random.uniform(0, 0.1))
            t2 = (u.x, u.y)
        return [t0, t1, t2]

    # full state vector fed to the networks (goal encoded in UAV frame)
    def state(self, uav, sim, goal=None):
        W, H = self.cfg.map_size
        if goal is None:
            blind = [u for u in sim.users if not u.bs_cover] if sim else []
            bad = [u for u in blind if not u._covered]
            if bad:
                u_near = min(bad, key=lambda x: _hypot(x.x - uav.x, x.y - uav.y))
                goal = (u_near.x, u_near.y)
            else:
                goal = (uav.x, uav.y)
        gx_n = goal[0] / W
        gy_n = goal[1] / H
        rdx = (goal[0] - uav.x) / W
        rdy = (goal[1] - uav.y) / H
        dist = _hypot(goal[0] - uav.x, goal[1] - uav.y)
        dist_n = np.clip(dist / 200.0, 0, 1)
        blind = [u for u in sim.users if not u.bs_cover] if sim else []
        bad = [u for u in blind if not u._covered]
        local_density = sum(1 for u in bad if _hypot(u.x - uav.x, u.y - uav.y) < 100.0)
        local_density = min(local_density / 10.0, 1.0)
        my_cov = sum(1 for u in blind if getattr(u, '_uav_id', -1) == uav.id)
        bias = my_cov / max(self.cfg.N_users, 1)
        return np.array([
            uav.x / W, uav.y / H,
            gx_n, gy_n,
            uav.vx / self.cfg.uav_speed_max,
            uav.vy / self.cfg.uav_speed_max,
            rdx, rdy,
            dist_n,
            local_density,
            uav.energy / 500.0,
            bias
        ], dtype=np.float32)

    # epsilon-greedy actor output with OU exploration noise
    def act(self, s, uav, sim):
        if not self.tf_ok:
            return self._heuristic_action(s)
        a = self.local_model.predict(s[np.newaxis], verbose=0)[0]
        decay = 1.0 - 0.8 * min(1.0, self.steps / 500.0)
        noise_scale_eps = 1.0 * decay
        noise_scale_exploit = 0.1 * decay
        if np.random.random() < self.cfg.eps:
            noise = self._ou_noise()
            a = np.clip(a + noise * noise_scale_eps, -1.0, 1.0)
        else:
            noise = self._ou_noise() * noise_scale_exploit
            a = np.clip(a + noise, -1.0, 1.0)
        return a.astype(np.float32)

    def _ou_noise(self):
        theta = self.cfg.ou_theta
        sigma = self.cfg.ou_sigma
        self._ou_state = (1 - theta) * self._ou_state + sigma * np.random.randn(self.cfg.action_dim)
        return self._ou_state.astype(np.float32)

    def _heuristic_action(self, s):
        rdx, rdy = float(s[6]), float(s[7])
        mag = _hypot(rdx, rdy) + 1e-6
        return np.array([rdx / mag, rdy / mag], dtype=np.float32)

    # map the actor output to a bounded 2D displacement command
    def dec2ctrl(self, a, uav, sim):
        W, H = self.cfg.map_size
        scale = self.cfg.uav_speed_max * self.cfg.dt * 2.0
        tx = float(np.clip(uav.x + a[0] * scale, 0, W))
        ty = float(np.clip(uav.y + a[1] * scale, 0, H))
        return tx, ty, 1.0

    # reward = sparse coverage + global CC gain - energy - time - far goal - UAV crowding
    def reward(self, uav, sim, goal=None):
        if sim is None:
            return 0.0
        blind = [u for u in sim.users if not u.bs_cover]
        my_cov = sum(1 for u in blind if getattr(u, '_uav_id', -1) == uav.id)
        r_cover = 0.0
        prev_my_cov = getattr(self, '_prev_my_cov', 0)
        if goal is not None:
            d_goal = _hypot(goal[0] - uav.x, goal[1] - uav.y)
            gain = my_cov - prev_my_cov
            if d_goal < 80.0 and gain > 0:
                r_cover = self.cfg.w_cover * (1.0 + min(gain, 3) * 0.5)
        self._prev_my_cov = my_cov
        cc = getattr(sim, '_cur_cc', 0.0)
        pc = getattr(sim, '_prev_cc', 0.0)
        if pc < 1e-8 and cc > 10:
            pc = cc
        r_global = self.cfg.w_global * max(0.0, (cc - pc) / 100.0)
        r_energy = -self.cfg.w_energy * uav._step_energy
        r_time = -self.cfg.w_time_penalty * (1.0 - np.exp(-uav.energy / 100.0))
        r_dist = 0.0
        if goal is not None:
            d_goal = _hypot(goal[0] - uav.x, goal[1] - uav.y)
            if d_goal > self.cfg.dist_far_threshold:
                r_dist = -self.cfg.w_dist_far
        r_repel = 0.0
        for other in sim.uavs:
            if other.id == uav.id: continue
            d = _hypot(other.x - uav.x, other.y - uav.y)
            if d < 80.0:
                r_repel -= 0.5 * (1.0 - d / 80.0)
        r = r_cover + r_global + r_energy + r_time + r_dist + r_repel
        self.ema_r = 0.95 * getattr(self, 'ema_r', 0.0) + 0.05 * r
        self.r_hist.append(r)
        return r

    def store(self, s, a, r, s2, done, goal=None, end_pos=None):
        if not self.tf_ok:
            return
        exp = (s, np.asarray(a, dtype=np.float32), r, s2, done)
        self.local_mem.append(exp)
        if self.her_buffer is not None and goal is not None:
            self.her_buffer.add(s, np.asarray(a, dtype=np.float32), r, s2, done, goal, end_pos)

    # one DDPG update: critic on replay + HER batch, actor by policy gradient
    def train(self, use_her=True):
        if not self.tf_ok or len(self.local_mem) < 2 * self.cfg.batch:
            return
        self._train_counter = getattr(self, '_train_counter', 0) + 1
        if self._train_counter % 2 != 0:
            return
        batch = [self.local_mem[i] for i in np.random.choice(len(self.local_mem), self.cfg.batch, replace=False)]
        if use_her and self.her_buffer is not None and len(self.her_buffer.buffer) >= self.cfg.batch:
            her_batch = self.her_buffer.sample(int(self.cfg.batch * 0.2))
            if her_batch:
                batch.extend(her_batch)
        S = np.array([x[0] for x in batch], dtype=np.float32)
        A = np.array([x[1] for x in batch], dtype=np.float32)
        R = np.array([x[2] for x in batch], dtype=np.float32)
        S2 = np.array([x[3] for x in batch], dtype=np.float32)
        D = np.array([x[4] for x in batch], dtype=np.float32)

        A2_target = self.target_model.predict(S2, verbose=0)
        Q2 = self.target_critic.predict([S2, A2_target], verbose=0).flatten()
        y = R + self.cfg.gamma * Q2 * (1 - D)

        loss_c = self.critic.train_on_batch([S, A], y)

        with tf.GradientTape() as tape:
            S_t = tf.convert_to_tensor(S, dtype=tf.float32)
            a_pred = self.local_model(S_t, training=True)
            q = self.critic([S_t, a_pred], training=False)
            actor_loss = -tf.reduce_mean(q)
        grads = tape.gradient(actor_loss, self.local_model.trainable_variables)
        self.local_model.optimizer.apply_gradients(zip(grads, self.local_model.trainable_variables))

        tau = self.cfg.tau
        for w, wt in zip(self.local_model.weights, self.target_model.weights):
            wt.assign(w * tau + wt * (1 - tau))
        for w, wt in zip(self.critic.weights, self.target_critic.weights):
            wt.assign(w * tau + wt * (1 - tau))

        self.l_hist.append(float(loss_c))
        self.steps += 1

class HierarchicalLeader:
    def __init__(self, cfg, fed_manager):
        self.cfg = cfg
        self.fed_manager = fed_manager
        self.tf_ok = tf is not None
        self.memory = deque(maxlen=cfg.high_mem_size)
        self.steps = 0
        self.eps = cfg.high_eps
        self._pending = {}
        if self.tf_ok:
            self.q_net = self._build_q()
            self.target_q = self._build_q()
            self.target_q.set_weights(self.q_net.get_weights())

    def _build_q(self):
        model = Sequential([
            Dense(64, input_dim=self.cfg.high_state_dim, activation='relu'),
            Dense(32, activation='relu'),
            Dense(self.cfg.high_action_dim, activation='linear')
        ])
        model.compile(optimizer=tf.keras.optimizers.Adam(self.cfg.high_lr), loss='mse')
        return model

    # normalised blind-user density per coarse grid cell
    def grid_density_map(self, sim):
        gs = self.cfg.grid_size
        step_x = self.cfg.map_size[0] / gs
        step_y = self.cfg.map_size[1] / gs
        grid = np.zeros((gs, gs), dtype=np.float32)
        for u in sim.users:
            if not u._covered:
                gx = int(np.clip(u.x // step_x, 0, gs-1))
                gy = int(np.clip(u.y // step_y, 0, gs-1))
                grid[gy, gx] += 1
        total = grid.sum()
        if total > 0:
            grid /= total
        return grid

    def grid_center(self, action_idx):
        gs = self.cfg.grid_size
        gy, gx = divmod(int(action_idx), gs)
        step_x = self.cfg.map_size[0] / gs
        step_y = self.cfg.map_size[1] / gs
        return ((gx + 0.5) * step_x, (gy + 0.5) * step_y)

    def count_covered_in_grid(self, sim, action_idx):
        gs = self.cfg.grid_size
        step_x = self.cfg.map_size[0] / gs
        step_y = self.cfg.map_size[1] / gs
        gy, gx = divmod(int(action_idx), gs)
        x_lo, x_hi = gx * step_x, (gx + 1) * step_x
        y_lo, y_hi = gy * step_y, (gy + 1) * step_y
        cnt = 0
        for u in sim.users:
            if u._covered and x_lo <= u.x < x_hi and y_lo <= u.y < y_hi:
                cnt += 1
        return cnt

    def _get_uav_grid(self, uav, sim):
        gs = self.cfg.grid_size
        step_x = self.cfg.map_size[0] / gs
        step_y = self.cfg.map_size[1] / gs
        gx = int(np.clip(uav.x // step_x, 0, gs - 1))
        gy = int(np.clip(uav.y // step_y, 0, gs - 1))
        return gy * gs + gx

    # pick the next sub-goal cell on the 3x3 coarse grid (high-level policy)
    def select_subgoal(self, sim, uav_idx):
        state_map = self.grid_density_map(sim).flatten()
        dim = self.cfg.high_action_dim
        self._flush(sim, uav_idx, s2=state_map)
        uav_penalty = np.zeros(dim, dtype=np.float32)
        for uav in sim.uavs:
            uav_penalty[self._get_uav_grid(uav, sim)] += 1.0
        uav_penalty = uav_penalty / max(1.0, uav_penalty.max())
        valid_mask = state_map >= 0.02
        cur_gi = self._get_uav_grid(sim.uavs[uav_idx], sim)
        if self.tf_ok and np.random.random() > self.eps:
            q_vals = self.q_net.predict(state_map[np.newaxis], verbose=0)[0]
            if valid_mask.any():
                q_vals = np.where(valid_mask, q_vals, -1e3)
                q_vals = q_vals - 0.3 * uav_penalty
                q_vals += 0.02 * np.cos(2.0 * np.pi * (np.arange(dim) - uav_idx) / dim)
                q_vals[cur_gi] -= 0.15
                action_idx = int(np.argmax(q_vals))
            else:
                action_idx = cur_gi
        else:
            valid = np.flatnonzero(valid_mask)
            if valid.size == 0:
                action_idx = cur_gi
            else:
                probs = np.array([1.0 - 0.5 * uav_penalty[i] for i in valid])
                probs = probs / probs.sum()
                action_idx = int(np.random.choice(valid, p=probs))
        self._pending[uav_idx] = {
            's': state_map,
            'a': action_idx,
            'cov0': self.count_covered_in_grid(sim, action_idx),
            'cc0': getattr(sim, '_cur_cc', 0.0),
            'e0': float(sim.uavs[uav_idx].energy),
        }
        return self.grid_center(action_idx), action_idx

    # settle the pending transition of one UAV with its real coverage gain
    def _flush(self, sim, uav_idx, s2=None):
        p = self._pending.pop(uav_idx, None)
        if p is None:
            return
        new_cov = self.count_covered_in_grid(sim, p['a']) - p['cov0']
        energy_cost = max(0.0, float(sim.uavs[uav_idx].energy) - p['e0'])
        reward = new_cov * self.cfg.w_high_cover - energy_cost * self.cfg.w_high_energy
        reward += 0.5 * max(0.0, getattr(sim, '_cur_cc', 0.0) - p['cc0'])
        if s2 is None:
            s2 = self.grid_density_map(sim).flatten()
        self.memory.append((p['s'], p['a'], float(reward), s2, False))

    def train(self):
        # DQN-style update on the coarse-grid transitions
        if not self.tf_ok or len(self.memory) < self.cfg.high_batch:
            return
        batch = [self.memory[i] for i in np.random.choice(len(self.memory), self.cfg.high_batch, replace=False)]
        S = np.array([x[0] for x in batch], dtype=np.float32)
        A = np.array([x[1] for x in batch], dtype=np.int32)
        R = np.array([x[2] for x in batch], dtype=np.float32)
        S2 = np.array([x[3] for x in batch], dtype=np.float32)
        D = np.array([x[4] for x in batch], dtype=np.float32)
        Q_cur = self.q_net.predict(S, verbose=0)
        Q_next = self.target_q.predict(S2, verbose=0).max(axis=1)
        targets = Q_cur.copy()
        for i, a in enumerate(A):
            targets[i, a] = float(R[i]) + self.cfg.high_gamma * float(Q_next[i]) * (1.0 - float(D[i]))
        self.q_net.train_on_batch(S, targets)
        self.steps += 1
        if self.steps % self.cfg.high_target_update == 0:
            self.target_q.set_weights(self.q_net.get_weights())
        if self.eps > self.cfg.high_eps_min:
            self.eps *= self.cfg.high_eps_decay

    def get_weights(self):
        return self.q_net.get_weights() if self.tf_ok else None

    def set_weights(self, weights, alpha=0.7):
        if not self.tf_ok or weights is None:
            return
        local_w = self.q_net.get_weights()
        new_w = [alpha * np.asarray(gw) + (1 - alpha) * np.asarray(lw)
                 for gw, lw in zip(weights, local_w)]
        self.q_net.set_weights(new_w)

class Building:
    # rectangular footprint plus height, type drives the penetration loss
    TYPES = {
        'commercial':  {'height': 60.0, 'img': 'commercial.png'},
        'office':      {'height': 40.0, 'img': 'office.png'},
        'residential': {'height': 20.0, 'img': 'residential.png'},
    }
    def __init__(self, x, y, w, h, btype='residential'):
        self.x, self.y, self.w, self.h = x, y, w, h
        self.type = btype
        self.height = self.TYPES.get(btype, {}).get('height', 20.0)

class User:
    # ground user: mobility, serving BS and priority zone
    def __init__(self, uid, x, y, cfg):
        self.id = uid
        self.cfg = cfg
        self.x, self.y = x, y
        self._ang = np.random.uniform(0, 2*np.pi)
        self._sp = max(0.05, np.random.normal(cfg.user_speed_mean, cfg.user_speed_std))
        self.vx = self._sp * np.cos(self._ang)
        self.vy = self._sp * np.sin(self._ang)
        self.cover_time = 0.0
        self.total_time = 0.0
        self.bs_cover = False
        self._covered = False
        self._uav_id = -1
        self.sinr = -999.0
        self.priority_zone = 'other'
        self.sinr_threshold = cfg.priority_sinr_thresholds['other']

    def update_priority_zone(self, buildings):
        R = self.cfg.priority_region_radius
        best_d = R + 1.0
        best_type = 'other'
        for b in buildings:
            cx = np.clip(self.x, b.x, b.x + b.w)
            cy = np.clip(self.y, b.y, b.y + b.h)
            d = _hypot(self.x - cx, self.y - cy)
            if d < best_d:
                best_d = d
                best_type = b.type
        if best_d > R:
            best_type = 'other'
        self.priority_zone = best_type
        self.sinr_threshold = self.cfg.priority_sinr_thresholds.get(best_type, 0.0)

    def step(self, dt):
        alpha = self.cfg.user_alpha
        self.vx = alpha*self.vx + (1-alpha)*self._sp*np.cos(self._ang) + np.sqrt(1-alpha**2)*np.random.normal(0,self.cfg.user_speed_std)
        self.vy = alpha*self.vy + (1-alpha)*self._sp*np.sin(self._ang) + np.sqrt(1-alpha**2)*np.random.normal(0,self.cfg.user_speed_std)
        self.x = np.clip(self.x + self.vx*dt, 0, self.cfg.map_size[0])
        self.y = np.clip(self.y + self.vy*dt, 0, self.cfg.map_size[1])
        if self.x < 1 or self.x > self.cfg.map_size[0]-1: self.vx *= -1
        if self.y < 1 or self.y > self.cfg.map_size[1]-1: self.vy *= -1

class BS:
    # ground base station with a fixed band assignment
    def __init__(self, bid, x, y, band=0):
        self.id, self.x, self.y, self.band = bid, x, y, band

class UAV:
    # UAV: kinematics, energy model, served users and its local DDPG agent
    def __init__(self, uid, x, y, cfg, sim=None, agent=None):
        self.id = uid
        self.cfg = cfg
        self.x, self.y, self.z = x, y, cfg.uav_opt_h
        self.sim = sim
        self.agent = agent
        self.vx = self.vy = self.vz = 0.0
        self.users = []
        self._cu = None
        self._tslot = 0
        self._s = None
        self._a = None
        self.sub_goal = (x, y)
        self.high_leader = None
        self.energy = 0.0
        self.flight_dist = 0.0
        self._step_energy = 0.0
        self.traj = [(x, y, cfg.uav_opt_h)]
        self.band = uid % cfg.n_bands
        self.last_goal = None

    def add_user(self, u):
        if u not in self.users:
            self.users.append(u)

    def clear_users(self):
        self.users = []

    @property
    def cur_user(self):
        return self._cu

    @cur_user.setter
    def cur_user(self, v):
        self._cu = v

    # one control step: velocity update, collision avoidance, low-level action, reward
    def update(self, dt, t, sim):
        self._tslot += 1
        px, py = self.x, self.y
        if self.sub_goal is None:
            blind = [u for u in sim.users if not u.bs_cover]
            bad = [u for u in blind if not u._covered]
            if bad:
                _exc = 120.0
                bad_far = [u for u in bad if all(
                    _hypot(u.x - o.x, u.y - o.y) > _exc
                    for o in sim.uavs if o.id != self.id)]
                u_near = min(bad_far if bad_far else bad,
                             key=lambda x: _hypot(x.x - self.x, x.y - self.y))
                self.sub_goal = (u_near.x, u_near.y)
            else:
                self.sub_goal = (self.x, self.y)
        d_to_goal = _hypot(self.sub_goal[0] - self.x, self.sub_goal[1] - self.y)
        if d_to_goal < 50.0 and self.high_leader is not None:
            sub_goal, action_idx = self.high_leader.select_subgoal(sim, self.id)
            self.sub_goal = sub_goal
        if self.users:
            self._cu = self.users[self._tslot % len(self.users)]
        else:
            self._cu = None
        st = self.agent.state(self, sim, goal=self.sub_goal) if self.agent else None
        a = None
        tx, ty, scale = self.x, self.y, 1.0
        if st is not None and self.agent:
            a = self.agent.act(st, self, sim)
            tx, ty, scale = self.agent.dec2ctrl(a, self, sim)
            self.last_goal = self.sub_goal
        else:
            blind = [u for u in sim.users if not u.bs_cover]
            bad = [u for u in blind if not u._covered]
            if bad:
                u_near = min(bad, key=lambda x: _hypot(x.x - self.x, x.y - self.y))
                tx = 0.7 * u_near.x + 0.3 * self.sub_goal[0]
                ty = 0.7 * u_near.y + 0.3 * self.sub_goal[1]
            else:
                tx = self.sub_goal[0]
                ty = self.sub_goal[1]
            tx = np.clip(tx, 0, self.cfg.map_size[0])
            ty = np.clip(ty, 0, self.cfg.map_size[1])
        dx, dy = tx-self.x, ty-self.y
        dst = _hypot(dx, dy)
        if dst > 1e-6:
            vmx = min(self.cfg.uav_speed_max*scale, dst/dt)
            self.vx += np.clip(dx/dst*vmx - self.vx, -self.cfg.uav_accel_max*dt, self.cfg.uav_accel_max*dt)
            self.vy += np.clip(dy/dst*vmx - self.vy, -self.cfg.uav_accel_max*dt, self.cfg.uav_accel_max*dt)
        else:
            self.vx *= 0.9; self.vy *= 0.9
        ax, ay = self.vx, self.vy
        safe_d = self.cfg.avoid_building_dist
        for b in sim.buildings:
            cx = np.clip(self.x + ax*dt, b.x - safe_d, b.x + b.w + safe_d)
            cy = np.clip(self.y + ay*dt, b.y - safe_d, b.y + b.h + safe_d)
            ddx = (self.x + ax*dt) - cx
            ddy = (self.y + ay*dt) - cy
            dd = _hypot(ddx, ddy)
            if dd < safe_d and dd > 1e-6:
                force = (safe_d - dd) / safe_d * self.cfg.avoid_force_gain
                ax += ddx/dd * force * dt
                ay += ddy/dd * force * dt
        safe_bs = self.cfg.avoid_bs_dist
        for b in sim.bs:
            ddx = (self.x + ax*dt) - b.x
            ddy = (self.y + ay*dt) - b.y
            dd = _hypot(ddx, ddy)
            if dd < safe_bs and dd > 1e-6:
                force = (safe_bs - dd) / safe_bs * self.cfg.avoid_force_gain
                ax += ddx/dd * force * dt
                ay += ddy/dd * force * dt
        for other in sim.uavs:
            if other.id == self.id: continue
            ddx = self.x - other.x
            ddy = self.y - other.y
            dd = _hypot(ddx, ddy)
            rep_d = 150.0
            if dd < rep_d and dd > 1e-6:
                force = (rep_d - dd) / rep_d * 80.0
                ax += ddx/dd * force * dt
                ay += ddy/dd * force * dt
        _m = 50.0
        if self.x < _m:
            ax += (_m - self.x) / _m * 40.0
        elif self.x > self.cfg.map_size[0] - _m:
            ax -= (self.x - (self.cfg.map_size[0] - _m)) / _m * 40.0
        if self.y < _m:
            ay += (_m - self.y) / _m * 40.0
        elif self.y > self.cfg.map_size[1] - _m:
            ay -= (self.y - (self.cfg.map_size[1] - _m)) / _m * 40.0
        new_vx = np.clip(ax, -self.cfg.uav_speed_max, self.cfg.uav_speed_max)
        new_vy = np.clip(ay, -self.cfg.uav_speed_max, self.cfg.uav_speed_max)
        self.vx = 0.7 * self.vx + 0.3 * new_vx
        self.vy = 0.7 * self.vy + 0.3 * new_vy
        nx = np.clip(self.x + self.vx*dt, 0, self.cfg.map_size[0])
        ny = np.clip(self.y + self.vy*dt, 0, self.cfg.map_size[1])
        if nx <= 1 or nx >= self.cfg.map_size[0] - 1:
            self.vx *= -0.3
        if ny <= 1 or ny >= self.cfg.map_size[1] - 1:
            self.vy *= -0.3
        for b in sim.buildings:
            if b.x <= nx <= b.x+b.w and b.y <= ny <= b.y+b.h:
                d_left = nx - b.x; d_right = (b.x+b.w) - nx
                d_down = ny - b.y; d_up = (b.y+b.h) - ny
                m = min(d_left, d_right, d_down, d_up)
                if m == d_left:   nx = b.x - 2
                elif m == d_right: nx = b.x + b.w + 2
                elif m == d_down: ny = b.y - 2
                else:              ny = b.y + b.h + 2
                self.vx *= 0.3; self.vy *= 0.3
        self.x, self.y = nx, ny
        look_ahead = max(30.0, abs(self.vx) * dt * 3.0, abs(self.vy) * dt * 3.0)
        fx = self.x + self.vx * dt * 4 + (self.vx * look_ahead / max(abs(self.vx)+abs(self.vy)+1e-6, 1.0))
        fy = self.y + self.vy * dt * 4 + (self.vy * look_ahead / max(abs(self.vx)+abs(self.vy)+1e-6, 1.0))
        fx = np.clip(fx, 0, self.cfg.map_size[0])
        fy = np.clip(fy, 0, self.cfg.map_size[1])
        need_h = self.cfg.uav_opt_h
        for b in sim.buildings:
            if (b.x - 25 <= fx <= b.x + b.w + 25 and
                b.y - 25 <= fy <= b.y + b.h + 25):
                need_h = max(need_h, b.height + 20)
        target_z = np.clip(need_h, self.cfg.uav_min_h, self.cfg.uav_max_h)
        dz = target_z - self.z
        self.vz += np.clip(dz * 0.5, -15.0 * dt, 15.0 * dt)
        self.vz *= 0.8
        self.z = np.clip(self.z + self.vz * dt, self.cfg.uav_min_h, self.cfg.uav_max_h)
        dist = _hypot(self.x-px, self.y-py)
        self.flight_dist += dist
        self._step_energy = self.cfg.k_energy * dist + self.cfg.k_hover * dt
        self.energy += self._step_energy
        self.traj.append((self.x, self.y, self.z))
        if self.agent and st is not None and a is not None:
            r = self.agent.reward(self, sim, goal=self.sub_goal)
            s2 = self.agent.state(self, sim, goal=self.sub_goal)
            done = False
            self.agent.store(st, a, r, s2, done, goal=self.sub_goal, end_pos=(self.x, self.y))
            self.agent.train(use_her=True)
            self._s = st
            self._a = a

class Sim:
    # full simulation: terrain, users, UAVs, training loop and figures
    def __init__(self, cfg):
        self.cfg = cfg
        np.random.seed(cfg.terrain_seed)
        self.log_lines = []

        rng_bs = np.random.RandomState(cfg.terrain_seed + 7)
        bs_positions = []
        min_bs_dist = 120
        margin = 60
        attempts_bs = 0
        while len(bs_positions) < cfg.N_ground_bs and attempts_bs < 2000:
            attempts_bs += 1
            bx_try = rng_bs.randint(margin, cfg.map_size[0] - margin)
            by_try = rng_bs.randint(margin, cfg.map_size[1] - margin)
            if all(_hypot(bx_try - sx, by_try - sy) > min_bs_dist for sx, sy in bs_positions):
                bs_positions.append((bx_try, by_try))
        if len(bs_positions) < cfg.N_ground_bs:
            n_extra = cfg.N_ground_bs - len(bs_positions)
            grid_n = int(np.ceil(np.sqrt(cfg.N_ground_bs)))
            gx = np.linspace(margin, cfg.map_size[0]-margin, grid_n)
            gy = np.linspace(margin, cfg.map_size[1]-margin, grid_n)
            for gi in range(grid_n):
                for gj in range(grid_n):
                    if len(bs_positions) >= cfg.N_ground_bs:
                        break
                    cand = (gx[gi], gy[gj])
                    if all(_hypot(cand[0]-sx, cand[1]-sy) > 60 for sx, sy in bs_positions):
                        bs_positions.append(cand)
                if len(bs_positions) >= cfg.N_ground_bs:
                    break
        self.buildings = []
        rng = np.random.RandomState(cfg.terrain_seed+1)
        n_com = max(2, int(cfg.N_buildings * 0.20))
        n_off = max(3, int(cfg.N_buildings * 0.33))
        n_res = cfg.N_buildings - n_com - n_off
        type_list = (['commercial'] * n_com + ['office'] * n_off + ['residential'] * n_res)
        rng.shuffle(type_list)
        type_size = {
            'commercial':  (22, 34),
            'office':      (18, 28),
            'residential': (14, 22),
        }
        attempts = 0
        while len(self.buildings) < cfg.N_buildings and attempts < 600:
            attempts += 1
            btype = type_list[len(self.buildings) % len(type_list)]
            s_lo, s_hi = type_size[btype]
            bw = rng.randint(s_lo, s_hi); bh = rng.randint(s_lo, s_hi)
            bx = rng.randint(50, cfg.map_size[0]-50-bw)
            by = rng.randint(50, cfg.map_size[1]-50-bh)
            bcx, bcy = bx+bw/2, by+bh/2
            if any(_hypot(bcx-bsx, bcy-bsy) < 42 for bsx, bsy in bs_positions):
                continue
            overlap = any(abs(bcx-o.x-o.w/2) < (bw+o.w)/2+6 and abs(bcy-o.y-o.h/2) < (bh+o.h)/2+6 for o in self.buildings)
            if overlap: continue
            self.buildings.append(Building(bx, by, bw, bh, btype))

        self.bs = [BS(i, bs_positions[i][0], bs_positions[i][1], band=i%cfg.n_bands) for i in range(cfg.N_ground_bs)]

        self.users = []
        uid = 0
        W, H = cfg.map_size
        n_near = max(1, cfg.N_users // max(1, cfg.N_ground_bs) // 2)
        rng_u = np.random.RandomState(cfg.terrain_seed + 11)
        for cx, cy in bs_positions:
            for _ in range(n_near):
                x = np.clip(cx + rng_u.normal(0, 45), 20, W - 20)
                y = np.clip(cy + rng_u.normal(0, 45), 20, H - 20)
                self.users.append(User(uid, x, y, cfg)); uid += 1
        n_blind = cfg.N_users - len(self.users)
        rng_b = np.random.RandomState(cfg.terrain_seed + 13)
        rel_pts = [
            (0.50, 0.50), (0.55, 0.35), (0.35, 0.55), (0.62, 0.62), (0.28, 0.28),
            (0.72, 0.28), (0.28, 0.72), (0.52, 0.78), (0.78, 0.18), (0.18, 0.78),
            (0.45, 0.16), (0.78, 0.62), (0.22, 0.48), (0.68, 0.52), (0.82, 0.42),
            (0.16, 0.62), (0.62, 0.85), (0.42, 0.22), (0.85, 0.72), (0.30, 0.82),
        ]
        for i in range(n_blind):
            rx, ry = rel_pts[i % len(rel_pts)]
            bx = rx * W
            by = ry * H
            x = np.clip(bx + rng_b.normal(0, 22), 20, W - 20)
            y = np.clip(by + rng_b.normal(0, 22), 20, H - 20)
            self.users.append(User(uid, x, y, cfg)); uid += 1

        self.fed_manager = FedManager(cfg, cfg.state_dim, cfg.action_dim)

        self.her_buffer = HERBuffer(capacity=cfg.mem_size, her_ratio=cfg.her_ratio, map_size=cfg.map_size)

        self.agents = []
        for i in range(cfg.N_uavs):
            agent = LocalDDPG(cfg, i, self.fed_manager, self.her_buffer)
            self.agents.append(agent)

        self.high_leader = HierarchicalLeader(cfg, self.fed_manager)

        W, H = cfg.map_size
        base_A = (int(0.06 * W), int(0.10 * H))
        base_B = (int(0.92 * W), int(0.90 * H))
        base_C = (int(0.06 * W), int(0.90 * H))
        base_D = (int(0.92 * W), int(0.10 * H))
        base_E = (int(0.50 * W), int(0.52 * H))
        jitter = list(itertools.product([-22, 0, 22], [-22, 0, 22]))
        rng_home = np.random.RandomState(cfg.terrain_seed + 17)
        jitter_idx = list(range(len(jitter)))
        rng_home.shuffle(jitter_idx)
        homes = []
        for bx, by in [base_A, base_B, base_C, base_D, base_E]:
            for k in range(2):
                if len(homes) >= cfg.N_uavs:
                    break
                dx, dy = jitter[jitter_idx[k % len(jitter_idx)]]
                homes.append((bx + dx, by + dy))
        self.uavs = []
        for i in range(cfg.N_uavs):
            hx = np.clip(homes[i][0], 10, W - 10)
            hy = np.clip(homes[i][1], 10, H - 10)
            u = UAV(i, hx, hy, cfg, self, self.agents[i])
            u.high_leader = self.high_leader
            self.uavs.append(u)

        self.cov_log = {'t':[], 'cum_cov':[], 'rew':[], 'eps':[], 'energy':[],
                        'uav_energy': [], 'uav_cov_counts': [], 'uav_flight_dist': []}
        self._prev_cc = 0.0; self._cur_cc = 0.0

    def _log(self, msg):
        self.log_lines.append(msg); print(msg, flush=True)

    # per-user SINR, coverage flags and cumulative coverage over time
    def eval_coverage(self, t):
        dt = self.cfg.dt
        warmup_t = getattr(self.cfg, 'warmup_t', 0.0)
        uav_contrib_enabled = (t >= warmup_t)
        for u in self.users:
            u.update_priority_zone(self.buildings)
            thr_u = u.sinr_threshold
            bs_sinr, _, _ = _bs_sinr(self.cfg, u, self.bs, self.buildings)
            u.bs_cover = (bs_sinr >= thr_u)
            u._uav_id = -1
            best_uav_sinr = -999.0
            uav_cov = False
            for v in self.uavs:
                d_manhattan = abs(v.x - u.x) + abs(v.y - u.y) + abs(v.z - 1.5)
                if d_manhattan > 520: continue
                sinr_v, _, _ = _uav_sinr(self.cfg, u, [v], want_uav_idx=0)
                if sinr_v >= thr_u and sinr_v > best_uav_sinr:
                    best_uav_sinr = sinr_v; uav_cov = True; u._uav_id = v.id
            u._covered = u.bs_cover or (uav_cov and uav_contrib_enabled)
            u.sinr = max(bs_sinr, best_uav_sinr)
            if uav_contrib_enabled:
                u.cover_time += dt if u._covered else 0
            else:
                u.cover_time += dt if u.bs_cover else 0
            u.total_time += dt
        self._cur_cc = self.cum_cov()

    # user association: nearest UAV that still has capacity
    def assign_users(self):
        for v in self.uavs: v.clear_users()
        need = [u for u in self.users if not u.bs_cover]
        if not need: return
        N = len(need); M = len(self.uavs)
        need_x = np.fromiter((u.x for u in need), dtype=np.float32, count=N)
        need_y = np.fromiter((u.y for u in need), dtype=np.float32, count=N)
        uav_x = np.fromiter((v.x for v in self.uavs), dtype=np.float32, count=M)
        uav_y = np.fromiter((v.y for v in self.uavs), dtype=np.float32, count=M)
        dx = need_x[:, None] - uav_x[None, :]
        dy = need_y[:, None] - uav_y[None, :]
        dists = np.sqrt(dx * dx + dy * dy)
        flat_idx = np.argsort(dists, axis=None)
        uav_load = np.zeros(M, dtype=np.int32)
        assigned = np.zeros(N, dtype=bool)
        max_per_uav = self.cfg.max_users_per_uav
        need_arr = np.asarray(need)
        for flat in flat_idx:
            if assigned.sum() >= N: break
            i, j = divmod(int(flat), M)
            if assigned[i]: continue
            if uav_load[j] >= max_per_uav: continue
            self.uavs[j].add_user(need_arr[i])
            assigned[i] = True
            uav_load[j] += 1

    def cum_cov(self):
        s = sum(u.cover_time / max(u.total_time, 1e-6) for u in self.users)
        return s / len(self.users) * 100.0

    def get_schedule_target(self, uav_idx):
        grid_size = self.cfg.grid_size
        step_x = self.cfg.map_size[0] / grid_size
        step_y = self.cfg.map_size[1] / grid_size
        grid_counts = np.zeros((grid_size, grid_size))
        for u in self.users:
            if not u._covered:
                gx = int(np.clip(u.x // step_x, 0, grid_size-1))
                gy = int(np.clip(u.y // step_y, 0, grid_size-1))
                grid_counts[gy, gx] += 1
        flat_idx = np.argsort(-grid_counts.flatten())
        slot = uav_idx % len(flat_idx)
        linear = flat_idx[slot]
        gy, gx = divmod(int(linear), grid_size)
        target_x = (gx + 0.5) * step_x
        target_y = (gy + 0.5) * step_y
        return (target_x, target_y)

    # one simulation step: move users -> evaluate coverage -> high-level decision
    # -> UAV updates -> federated aggregation -> logging
    def step(self, idx):
        cfg = self.cfg
        t = idx * cfg.dt
        self._cur_t = t
        for u in self.users: u.step(cfg.dt)
        self.eval_coverage(t)
        self.assign_users()
        if idx % cfg.high_decision_interval == 0:
            for i, v in enumerate(self.uavs):
                sub_goal, action_idx = self.high_leader.select_subgoal(self, i)
                v.sub_goal = sub_goal
        for v in self.uavs: v.update(cfg.dt, t, self)
        if idx % cfg.high_decision_interval == 0 and idx > 0:
            self.high_leader.train()
        if self.fed_manager.should_aggregate():
            local_weights = [w for w in (a.get_weights() for a in self.agents) if w is not None]
            if local_weights:
                context_vectors = [self.fed_manager.get_context_vector(uav) for uav in self.uavs]
                attn = self.fed_manager.aggregate(local_weights, context_vectors)
                global_w = self.fed_manager.get_global_weights()
                for agent in self.agents:
                    agent.set_weights(global_w)
                high_w = self.high_leader.get_weights()
                if high_w is not None:
                    self.high_leader.set_weights(high_w, alpha=0.5)
                self.fed_manager.compute_model_diff(local_weights)
        if cfg.eps > cfg.eps_min:
            cfg.eps *= cfg.eps_decay
        cc = self._cur_cc
        rews = [float(np.mean(a.r_hist[-10:])) for a in self.agents if a.r_hist]
        r = float(np.mean(rews)) if rews else 0.0
        en = float(sum(v.energy for v in self.uavs))
        uav_en = [float(v.energy) for v in self.uavs]
        self.cov_log['t'].append(t)
        self.cov_log['cum_cov'].append(cc)
        self.cov_log['rew'].append(r)
        self.cov_log['eps'].append(cfg.eps)
        self.cov_log['energy'].append(en)
        self.cov_log['uav_energy'].append(uav_en)
        if idx % 10 == 0:
            cov_counts = [len(v.users) for v in self.uavs]
            flt_dists = [float(v.flight_dist) for v in self.uavs]
            self.cov_log['uav_cov_counts'].append(cov_counts)
            self.cov_log['uav_flight_dist'].append(flt_dists)
        self._prev_cc = cc
        if idx % 5 == 0:
            self._log(f"step={idx:5d} t={t:6.1f}s  CC={cc:5.1f}%  rew={r:6.2f}  E={en:7.1f}J")
        return cc, r

    # sample the SINR field once; the 2D and 3D figures share this result
    def _compute_sinr_grid(self, n=80):
        gx = np.linspace(0, self.cfg.map_size[0], n)
        gy = np.linspace(0, self.cfg.map_size[1], n)
        GX, GY = np.meshgrid(gx, gy)
        SINR = np.zeros_like(GX)

        class _FU:
            pass

        u = _FU()
        for i in range(n):
            for j in range(n):
                u.x, u.y = GX[i, j], GY[i, j]
                sinr_bs, _, _ = _bs_sinr(self.cfg, u, self.bs, self.buildings)
                best_uav = -999.0
                for v in self.uavs:
                    sinr_v, _, _ = _uav_sinr(self.cfg, u, [v], want_uav_idx=0)
                    if sinr_v > best_uav:
                        best_uav = sinr_v
                SINR[i, j] = max(sinr_bs, best_uav)
        return GX, GY, SINR

    # 2D map: SINR contours, PNG building/base-station icons and UAV trajectories
    def plot(self, out_dir='sim_output', run_suffix=None):
        os.makedirs(out_dir, exist_ok=True)
        try:
            _SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
        except NameError:
            _SCRIPT_DIR = os.getcwd()

        fig, ax = plt.subplots(figsize=(13, 10.5))
        fig.patch.set_facecolor('#ffffff')
        ax.set_facecolor('#ffffff')

        GX, GY, SINR_grid = self._compute_sinr_grid(80)
        self._sinr_cache = (GX, GY, SINR_grid)

        cf2 = ax.contourf(GX, GY, SINR_grid, levels=np.linspace(-15, 35, 25),
                          cmap='RdYlGn_r', alpha=0.55, extend='both')
        ax.contour(GX, GY, SINR_grid, levels=np.arange(-12, 33, 6),
                   colors='#3a3a3a', linewidths=0.5, alpha=0.45)
        cbar = plt.colorbar(cf2, ax=ax, shrink=0.55, pad=0.06, location='right', label='SINR (dB)')
        cbar.ax.axhline(self.cfg.sinr_threshold_db, color='#a30543', ls='--', lw=1.5, alpha=0.6)
        cbar.ax.tick_params(labelsize=11)

        building_imgs = {}
        _sd = _SCRIPT_DIR
        for btype, info in Building.TYPES.items():
            img_path = os.path.join(_sd, info['img'])
            if os.path.exists(img_path):
                try:
                    building_imgs[btype] = plt.imread(img_path)
                except Exception:
                    building_imgs[btype] = None
            else:
                building_imgs[btype] = None
        type_colors = {
            'commercial':  '#4a5a6a',
            'office':      '#6a7a8a',
            'residential': '#8a9aaa',
        }
        for b in self.buildings:
            has_img = building_imgs.get(b.type) is not None
            if has_img:
                rect = plt.Rectangle((b.x, b.y), b.w, b.h, facecolor='none',
                                     edgecolor='none', linewidth=0, zorder=3)
            else:
                rect = plt.Rectangle((b.x, b.y), b.w, b.h, facecolor=type_colors.get(b.type, '#6a7a8a'),
                                     edgecolor='none', alpha=0.35, linewidth=0, zorder=3)
            ax.add_patch(rect)
        for b in self.buildings:
            img = building_imgs.get(b.type)
            if img is not None:
                ax.imshow(img, extent=(b.x, b.x+b.w, b.y, b.y+b.h),
                          zorder=4, aspect='auto', interpolation='bilinear')

        bs_img_loaded = False
        bs_icon_size = 42
        for bs_img_name in ['station.png', 'station.jpg', 'station.jpeg']:
            bs_img_path = os.path.join(_SCRIPT_DIR, bs_img_name)
            if not os.path.exists(bs_img_path):
                bs_img_path = os.path.join(os.path.dirname(_SCRIPT_DIR), bs_img_name)
                if not os.path.exists(bs_img_path):
                    continue
            try:
                bs_img = plt.imread(bs_img_path)
                bs_img_loaded = True
                for b in self.bs:
                    ax.imshow(bs_img, extent=(b.x - bs_icon_size / 2, b.x + bs_icon_size / 2,
                                              b.y - bs_icon_size / 2, b.y + bs_icon_size / 2),
                              zorder=5, aspect='auto', interpolation='bilinear')
                break
            except Exception as e:
                print(f"Failed to load base station icon: {e}")
                continue

        if not bs_img_loaded:
            print("WARNING: station.png not found, using square markers for base stations")
            for b in self.bs:
                ax.scatter(b.x, b.y, marker='s', s=400, color='#274753',
                           edgecolor='#f3a361', linewidth=2.5, zorder=5,
                           label='BS' if b.id == 0 else '')

        n_colors = len(self.uavs)
        uav_colors = PALETTE_DUSK[:n_colors] if n_colors <= len(PALETTE_DUSK) else (
            PALETTE_DUSK + PALETTE_VITAL)[:n_colors]
        for i, v in enumerate(self.uavs):
            traj = np.array(v.traj)
            if len(traj) < 2: continue
            c = uav_colors[i]
            n_pts = len(traj)
            ax.plot(traj[:, 0], traj[:, 1], color=c, lw=2.0, alpha=0.90,
                    linestyle='-', solid_capstyle='round', solid_joinstyle='round',
                    zorder=4)
            if n_pts > 10:
                idx = int(n_pts * 0.55)
                idx = max(2, min(idx, n_pts - 3))
                ax.annotate('', xy=(traj[idx+1, 0], traj[idx+1, 1]),
                            xytext=(traj[idx-1, 0], traj[idx-1, 1]),
                            arrowprops=dict(arrowstyle='->', color=c, lw=1.8, alpha=0.95),
                            zorder=6)
            ax.scatter(traj[0, 0], traj[0, 1], s=110, facecolor='white',
                       edgecolor=c, linewidth=2.0, marker='o', zorder=7, alpha=0.95)
            ax.annotate('S', (traj[0, 0], traj[0, 1]), fontsize=8, color=c,
                        fontweight='bold', ha='center', va='center')
            ax.scatter(v.x, v.y, s=280, color=c,
                       edgecolor='white', linewidth=1.8, marker='*', zorder=8, label=f'UAV{i+1}')
            ax.annotate(f'U{i+1}', (v.x, v.y), fontsize=10, color=c,
                        fontweight='bold', ha='center', va='bottom',
                        xytext=(0, 8), textcoords='offset points')

        ax.set_xlim(0, self.cfg.map_size[0])
        ax.set_ylim(0, self.cfg.map_size[1])
        ax.set_aspect('equal')
        ax.set_xlabel('X (m)', fontsize=15, color='#444444')
        ax.set_ylabel('Y (m)', fontsize=15, color='#444444')
        ax.set_title(f'UAV Trajectories & SINR Coverage Map (CC={self.cum_cov():.2f}%)',
                     fontsize=18, fontweight='bold', pad=12, color='#333333')
        ax.grid(True, alpha=0.1, linestyle=':', color='#888888')
        for spine in ax.spines.values():
            spine.set_linewidth(0.8)
            spine.set_color('#999999')
        handles, labels = ax.get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        ax.legend(by_label.values(), by_label.keys(),
                  loc='center right', bbox_to_anchor=(-0.1, 0.5),
                  frameon=True, fancybox=True, fontsize=11, ncol=1,
                  edgecolor='#cccccc', framealpha=0.95,
                  borderaxespad=0, labelspacing=0.9)
        fig.subplots_adjust(left=0.12, right=0.88)
        fig.savefig(f'{out_dir}/trajectory_hfdrl{("_" + run_suffix) if run_suffix else ""}.png', dpi=300, bbox_inches='tight')
        plt.close(fig)

        self._plot_3d(out_dir, run_suffix=run_suffix)

        self._log(f"Figures saved to {out_dir}/")

    # 3D view: SINR surface at ground level, extruded buildings and flight paths
    def _plot_3d(self, out_dir='sim_output', run_suffix=None):
        cfg = self.cfg

        GX, GY, SINR_grid = getattr(self, '_sinr_cache', None) or self._compute_sinr_grid(80)
        _sl = (slice(None, None, 2), slice(None, None, 2))
        GX, GY, SINR_grid = GX[_sl], GY[_sl], SINR_grid[_sl]

        z_min_view = -5.0
        max_terrain_val = float(np.max(SINR_grid))
        max_building_h = max((b.height for b in self.buildings), default=60.0)
        max_uav_h = 0.0
        for v in self.uavs:
            if v.traj:
                max_uav_h = max(max_uav_h, float(max(p[2] for p in v.traj)))
            max_uav_h = max(max_uav_h, float(v.z))
        z_max_view = max(max_terrain_val, max_building_h, max_uav_h) + 25.0

        n_colors = len(self.uavs)
        uav_colors = PALETTE_DUSK[:n_colors] if n_colors <= len(PALETTE_DUSK) else (
            PALETTE_DUSK + PALETTE_VITAL)[:n_colors]

        btype_colors_3d = {
            'commercial': ('#2a3a4a', '#4a6a8a'),
            'office': ('#3a5a6a', '#5a8a9a'),
            'residential': ('#4a6a7a', '#7aaaba'),
        }

        suffix = f"_{run_suffix}" if run_suffix else ""

        fig = plt.figure(figsize=(14, 10), facecolor='#ffffff')
        ax3d = fig.add_subplot(111, projection='3d')
        ax3d.set_facecolor('#ffffff')

        surf = ax3d.plot_surface(GX, GY, SINR_grid, cmap='RdYlGn_r',
                                   alpha=0.72, shade=True, rstride=2, cstride=2,
                                   vmin=-15, vmax=35, edgecolor='none')
        ax3d.contour(GX, GY, SINR_grid, zdir='z', offset=z_min_view,
                      levels=np.arange(-12, 33, 6), cmap='RdYlGn_r',
                      linewidths=0.6, alpha=0.5)

        for b in self.buildings:
            h = b.height
            fc, ec = btype_colors_3d.get(b.type, ('#4a5a6a', '#6a8a9a'))
            ax3d.bar3d(b.x, b.y, 0, b.w, b.h, h,
                        color=fc, alpha=0.55, edgecolor=ec,
                        linewidth=0.3, shade=True)

        for i, v in enumerate(self.uavs):
            traj = np.array(v.traj)
            if len(traj) < 2: continue
            tz = traj[:, 2]
            c = uav_colors[i]
            ax3d.plot(traj[:, 0], traj[:, 1], tz[:],
                       color=c, lw=2.0, alpha=0.92,
                       solid_capstyle='round', solid_joinstyle='round')
            ax3d.scatter([traj[0, 0]], [traj[0, 1]], [tz[0]], s=60,
                          facecolor='white', edgecolor=c,
                          linewidth=1.6, marker='o', zorder=6)
            ax3d.scatter([v.x], [v.y], [v.z], s=120,
                          color=c, edgecolor='white',
                          linewidth=1.4, marker='*', zorder=7)

        for b in self.bs:
            ax3d.scatter([b.x], [b.y], [0], s=220,
                          color='#274753', edgecolor='#f3a361',
                          linewidth=2.0, marker='s', zorder=7,
                          label='BS' if b.id == 0 else '')

        ax3d.set_xlabel('X (m)', fontsize=12, labelpad=6, color='#555555')
        ax3d.set_ylabel('Y (m)', fontsize=12, labelpad=6, color='#555555')
        ax3d.set_xlim(0, cfg.map_size[0])
        ax3d.set_ylim(0, cfg.map_size[1])
        ax3d.set_zlim(z_min_view, z_max_view)
        ax3d.set_title(f'3D Aerial View (CC={self.cum_cov():.2f}%)',
                        fontsize=16, fontweight='bold', pad=12, color='#333333')
        ax3d.view_init(elev=35, azim=-45)
        ax3d.xaxis.pane.set_facecolor('#ffffff')
        ax3d.yaxis.pane.set_facecolor('#ffffff')
        ax3d.zaxis.pane.set_facecolor('#ffffff')
        ax3d.xaxis.pane.set_edgecolor('#dddddd')
        ax3d.yaxis.pane.set_edgecolor('#dddddd')
        ax3d.zaxis.pane.set_edgecolor('#dddddd')
        cbar = fig.colorbar(surf, ax=ax3d, shrink=0.5, pad=0.08, location='right',
                            label='SINR (dB)', aspect=18)
        cbar.ax.axhline(cfg.sinr_threshold_db, color='#a30543', ls='--', lw=1.2)
        cbar.ax.tick_params(labelsize=10)
        fig.subplots_adjust(left=0.08, right=0.88)
        fig.tight_layout()
        fig.savefig(f'{out_dir}/trajectory_3d_wireframe_hfdrl{suffix}.png', dpi=250)
        plt.close(fig)

    # merge all runs into one workbook, one sheet per metric
    def to_excel_combined(self, sim_list, runtime_secs, out_path):
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        writer = pd.ExcelWriter(out_path, engine='openpyxl')
        n_runs = len(sim_list)
        n_uav = len(sim_list[0].uavs)
        t = sim_list[0].cov_log['t']

        summary_rows = []
        for i, sim in enumerate(sim_list):
            final_cc = sim.cum_cov()
            total_energy = float(sum(v.energy for v in sim.uavs))
            row = {
                'Run': f'Run_{i+1:02d}',
                'Final cumulative coverage (%)': round(final_cc, 2),
                'Total energy (J)': round(total_energy, 2),
                'Runtime (s)': round(float(runtime_secs[i]), 2),
                'Simulated duration (s)': float(t[-1]) if t else 0.0,
                'Simulation steps': len(t),
            }
            for j, v in enumerate(sim.uavs):
                row[f'UAV{j+1} energy (J)'] = round(float(v.energy), 2)
            summary_rows.append(row)
        df_summary = pd.DataFrame(summary_rows)
        num_cols = [c for c in df_summary.columns if c != 'Run']
        for label, fn in [('mean', np.mean), ('std', np.std), ('min', np.min), ('max', np.max)]:
            row = {'Run': label}
            for c in num_cols:
                vals = pd.to_numeric(df_summary[c], errors='coerce').dropna()
                row[c] = round(float(fn(vals)), 3) if len(vals) else None
            df_summary = pd.concat([df_summary, pd.DataFrame([row])], ignore_index=True)
        df_summary.to_excel(writer, sheet_name='Summary', index=False)

        cov_data = {'time_s': t}
        for i, sim in enumerate(sim_list):
            cov_data[f'Run{i+1}_coverage_%'] = sim.cov_log['cum_cov']
        pd.DataFrame(cov_data).to_excel(writer, sheet_name='Coverage', index=False)

        en_data = {'time_s': t}
        for i, sim in enumerate(sim_list):
            en_data[f'Run{i+1}_total_energy_J'] = sim.cov_log['energy']
        pd.DataFrame(en_data).to_excel(writer, sheet_name='Total energy', index=False)

        uav_en_data = {'time_s': t}
        for i, sim in enumerate(sim_list):
            uav_en_arr = np.array(sim.cov_log['uav_energy'])
            for j in range(n_uav):
                uav_en_data[f'Run{i+1}_UAV{j+1}_energy_J'] = uav_en_arr[:, j]
        pd.DataFrame(uav_en_data).to_excel(writer, sheet_name='Per-UAV energy', index=False)

        rew_data = {'time_s': t}
        for i, sim in enumerate(sim_list):
            rew_data[f'Run{i+1}_reward'] = sim.cov_log['rew']
        pd.DataFrame(rew_data).to_excel(writer, sheet_name='Reward', index=False)

        eps_data = {'time_s': t}
        for i, sim in enumerate(sim_list):
            eps_data[f'Run{i+1}_epsilon'] = sim.cov_log['eps']
        pd.DataFrame(eps_data).to_excel(writer, sheet_name='Epsilon', index=False)

        writer.close()
        self._log(f" Merged data of {n_runs} runs written to: {out_path}")

if __name__ == '__main__':
    # 20 independent runs with distinct random seeds
    N_RUNS = 20
    BASE_SEED = (int(time.time() * 1000) ^ os.getpid() ^ 0xA5A5) & 0xFFFFFFFF
    EXCEL_PATH = 'sim_output/results_20runs_hfdrl.xlsx'

    base_cfg = Config()
    total_steps = int(base_cfg.T_sim / base_cfg.dt)
    os.makedirs('sim_output', exist_ok=True)

    sim_list = []
    runtime_secs = []
    big_t0 = time.time()

    for i in range(1, N_RUNS + 1):
        cfg = Config()
        cfg.terrain_seed = (BASE_SEED ^ (i * 0x9E3779B1) ^ int(time.time() * 1000)) & 0xFFFFFFFF
        print(f"[Run {i:02d}/{N_RUNS:02d}] ")
        t0 = time.time()
        sim = Sim(cfg)
        for s in range(total_steps):
            sim.step(s)
        runtime_sec = time.time() - t0

        final_cc = sim.cum_cov()
        total_energy = sum(v.energy for v in sim.uavs)
        print(f"[Run {i:02d}] done  CC={final_cc:.2f}%  E={total_energy:.1f}J  t={runtime_sec:.1f}s")

        sim_list.append(sim)
        runtime_secs.append(runtime_sec)

        sim.plot(run_suffix=f'Run_{i:02d}')

    sim_list[0].to_excel_combined(sim_list, runtime_secs, EXCEL_PATH)

    total_all_sec = time.time() - big_t0
    ccs = [s.cum_cov() for s in sim_list]
    print(f"[All] {N_RUNS} runs finished, merged data: {EXCEL_PATH}")
    print(f"[All] CC per run: {' / '.join(f'{c:.2f}%' for c in ccs)}")
    print(f"[All] mean={np.mean(ccs):.2f}%  std={np.std(ccs):.2f}%  time={total_all_sec:.1f}s")